MX1
===

.. literalinclude:: ../../examples/ldnsx-mx1.py
	:language: python
	:linenos:
