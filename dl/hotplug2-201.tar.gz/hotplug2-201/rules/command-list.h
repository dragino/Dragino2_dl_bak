#ifndef RULES_COMMAND_LIST_H
#define RULES_COMMAND_LIST_H 1

#include "command.h"

extern struct command_def_t commands[];

#endif /* RULES_COMMAND_LIST_H */

