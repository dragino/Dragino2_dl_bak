This is my first attempt at a python wrapper. I'm not a python programmer so it
works, but ain't pretty. If you can make it more pythonic I'd love to hear from
you!

Thanks,

Roger
